from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def generate_reply(user_input):
    user_input = user_input.lower()
    if "hello" in user_input:
        return "Hi there! How can I help you?"
    elif "how are you" in user_input:
        return "I'm just code, but I'm doing great! 😊"
    elif "bye" in user_input:
        return "Goodbye! Take care 💖"
    elif "your name" in user_input:
        return "I'm your Internship Chatbot 🤖"
    else:
        return "I'm not sure I understand. Try asking something else!"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json["message"]
    bot_reply = generate_reply(user_message)
    return jsonify({"reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)
